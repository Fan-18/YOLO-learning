from ultralytics import YOLO
import datetime
import pytz
if __name__ == '__main__':
    yaml_name = 'yolov8s-C2f-DySnakeConv-LSKA'
    model = YOLO('ultralytics/cfg/models/v8/yolov8+OREPA.yaml')
    # model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='D:/YoloCode/ultralytics-main/ultralytics/mydata/data.yaml',
                cache=False,
                imgsz=640,
                epochs=2,
                batch=1,
                close_mosaic=10,
                workers=1,
                optimizer='SGD', # using SGD, Adam, AdamW
                # resume='runs/train/exp33/last.pt', # last.pt path
                # amp=False # close amp
                # fraction=0.2,
                project='runs/train',
                name='exp',
                )